## Machine truth layer

The machine truth layer has two files:
- `week_config.json` — weekly input. Translated from `week_constraints.md` by AI each week.
- `src/kitchen_data.py` — stable restaurant truth. Translated from `kitchen_state.md` only when roster changes.

There is no separate mapping file or generated config. `week_config.json` IS the machine input.
It is loaded directly by `kitchen_data.py` at import time.

# Output formats

## kitchen_state.md
Should remain parser-friendly and human-readable.
Recommended sections:
- Restaurant Info
- Core Roles and Stations
- Staffing Requirements
- Employee Skill Matrix
- Persistent Hard Constraints
- Persistent Soft Preferences
- Known Fragility
- Known Contradictions
- Unresolved Static Questions
- Assumptions

## week_constraints.md
Should combine chef-readable notes with machine-usable extraction.
Recommended sections:
- Week Info
- Chef Weekly Notes
- Availability Changes
- Service Intensity Forecast
- Temporary Hard Constraints
- Temporary Soft Preferences
- Training Priorities This Week
- Special Events / Exceptions
- Extracted Structured Constraints
- Unresolved Weekly Questions
- Assumptions

## schedule_output.xlsx
Required workbook structure:
- `Instructions`
- `Employees`
- `Station_Coverage`
- `Daily_Schedule`
- `Validation_Input`
- `Summary`

Recommended `Daily_Schedule` columns:
- Day
- Service
- Station
- Assigned Employee
- Coverage Type
- Time / Notes
- Validation Status

Recommended `Summary` sections:
- total shifts per employee
- total days per employee
- station coverage by day
- unresolved coverage gaps
- validator warnings summary

## validator_report.md
Recommended sections:
- Validation status
- Constraint checks
- Errors
- Warnings
- Assumptions
- Fragility notes
- Repair options

## schedule.json
Optional stable schema:
```json
{
  "week_start": "YYYY-MM-DD",
  "restaurant_name": "string",
  "assignments": [
    {
      "day": "string",
      "service": "string",
      "station": "string",
      "employee_name": "string",
      "coverage_type": "stable|learning|emergency",
      "notes": "string"
    }
  ],
  "assumptions": ["string"],
  "uncovered_requirements": [
    {
      "day": "string",
      "service": "string",
      "station": "string",
      "reason": "string"
    }
  ]
}
```

## solver_input.json
Include:
- restaurant metadata
- employees
- stations
- day/service requirements
- eligibility matrix with capability levels
- availability matrix
- persistent hard constraints
- temporary hard constraints
- soft objectives
- assumptions
- known contradictions


## config diff summary
Optional but recommended before solve:
- what changed in `src/kitchen_data.py`
- what changed in `week_config.json`
- any markdown fact that could not be represented cleanly
