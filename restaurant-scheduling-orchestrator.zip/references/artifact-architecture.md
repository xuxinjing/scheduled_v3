# Artifact architecture

Use this architecture consistently.

## Truth layers

### 1. kitchen_state.md
Static truth source.
Changes only when restaurant reality changes.
Examples:
- someone learned a new station reliably
- station definitions changed
- permanent role ownership changed

### 2. week_constraints.md
Dynamic weekly truth source.
Changes every planning cycle.
Examples:
- vacation
- service forecast
- temporary training goals
- temporary no-overtime instruction

## Execution sync layer

### 3. src mapping layer + generated config
This layer must be refreshed from `kitchen_state.md` and `week_constraints.md` before solving.
Keep it simple:
- one mapping file in `src/`
- one generated config file used by the solver stack

This layer can include station maps, availability tables, capability maps, constraints, and objective weights.
If code values disagree with markdown truth, update the mapping layer first, regenerate config second.

## Output layers

### 4. schedule_output.xlsx
Operational artifact used by manager / chef.
This is where the final weekly plan is reviewed and used.

### 5. validator_report.md
Explanation layer that tells whether the output is valid, fragile, or broken.

## Optional analysis layers
- solver_input.json
- repair_options.md
- delta_report.md

## Principle
Do not bury all logic in the prompt.
Put stable truth into files.
Then explicitly sync that truth into the mapping layer, regenerate config, and only then solve.
That makes review, versioning, validation, and solver handoff much more reliable without adding unnecessary engineering layers.
