# kitchen_state.md template

## Restaurant Info
- restaurant_name:
- service_model:
- seasonality_modes:
- scheduling_philosophy:

## Core Roles and Stations
For each station include:
- station_name:
- description:
- heat_level:
- criticality:
- merge_permissions:
- cannot_merge_with:
- notes:

## Staffing Requirements
### Peak season
For each required function include:
- station_name:
- required_headcount:
- notes:

### Slow season
For each required function include:
- station_name:
- required_headcount:
- allowed_merge:
- notes:

## Employee Skill Matrix
For each employee include:
- employee_name:
- title:
- stable_stations:
- learning_stations:
- emergency_only_stations:
- fixed_role_ownership:
- flexibility_level: high / medium / low
- reliability_notes:
- development_notes:

## Persistent Hard Constraints
- fixed station ownership
- permanent role restrictions
- overtime restrictions that are long-lived
- no-solo rules for unstable staff
- persistent leadership coverage rules

## Persistent Soft Preferences
- preferred training progression
- cost preferences
- staffing style preferences
- preferred use of versatile staff

## Known Fragility
- bottleneck stations:
- thin coverage points:
- single-point-of-failure risks:

## Known Contradictions
- contradiction:
- why_it_conflicts:
- severity:

## Unresolved Static Questions
- question:
- why_it_matters:

## Assumptions
List only assumptions needed to keep the state readable.
