# Escalation rules

Switch from direct reasoning to solver-prep mode when any of the following are true:
- more than 10 active employees with overlapping constraints
- multiple bottleneck stations each with thin depth
- several capability levels matter at once: stable, learning, emergency-only
- many temporary weekly exceptions
- repeated contradictions during draft generation
- merged-station logic creates combinatorial ambiguity
- the model starts revisiting the same conflicts without converging
- the user explicitly asks for OR-Tools, CP-SAT, MILP, or solver input

When escalating:
1. keep `kitchen_state.md` and `week_constraints.md` as truth sources
2. summarize bottlenecks
3. generate `solver_input.json`
4. separate hard constraints from soft objectives
5. preserve assumptions and known contradictions
