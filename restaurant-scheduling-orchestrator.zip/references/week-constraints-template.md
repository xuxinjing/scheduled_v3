# week_constraints.md template

## Week Info
- week_start:
- planning_horizon:
- generated_from:

## Chef Weekly Notes (Natural Language)
Paste the chef's raw or lightly cleaned weekly guidance here.

## Availability Changes
For each employee include:
- employee_name:
- unavailable_days_or_windows:
- requested_off_days:
- vacation:
- notes:

## Service Intensity Forecast
For each day include:
- day:
- intensity: low / medium / high / peak
- reason:

## Temporary Hard Constraints
Examples:
- someone cannot work a station this week
- someone must leave early
- no overtime this week for a specific person
- one merged station setup is forbidden this week

## Temporary Soft Preferences
Examples:
- give someone one safe training rep
- avoid back-to-back difficult nights
- prefer specific pairing this week

## Training Priorities This Week
For each employee include:
- employee_name:
- target_station:
- exposure_type: observe / assist / solo-light / solo-full
- notes:

## Special Events / Exceptions
- event:
- day:
- operational_impact:

## Extracted Structured Constraints
### Temporary hard rules
- rule:
- affected_people:
- affected_days:

### Temporary soft rules
- rule:
- affected_people:
- affected_days:

### Risk notes
- risk:
- mitigation:

## Unresolved Weekly Questions
- question:
- why_it_matters:

## Assumptions
List only week-specific assumptions.
