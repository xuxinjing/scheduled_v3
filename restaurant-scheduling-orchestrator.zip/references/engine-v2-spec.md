# Acquerello Scheduling Engine v2 Spec

## System objective
Create a scheduling system that is reviewable by chefs, parseable by machines, and robust enough for validator and solver workflows.

## Core contract
Input layers:
- kitchen_state.md
- week_constraints.md

Output layers:
- schedule_output.xlsx
- validator_report.md

Optional advanced layers:
- schedule.json
- solver_input.json
- delta_report.md

## Logic order
1. ingest static truth
2. ingest weekly dynamic truth
3. update the `src/` mapping layer from both markdown truth layers
4. regenerate the generated config
5. verify the generated config matches the markdown truth
6. detect contradictions
7. choose scheduling mode
8. generate schedule draft
9. validate schedule
10. emit repairs or escalate if needed

## Constraint model
### Hard constraints
Must not be violated.
Examples:
- fixed station ownership
- unavailable day
- role ineligibility
- no overtime for protected employee
- required leadership coverage

### Soft constraints
Can be traded off if needed.
Examples:
- training exposure
- fairness
- preferred pairing
- labor optimization beyond feasibility

## Capability levels
Use at least these levels:
- stable
- learning
- emergency-only
- not qualified

The solver / validator must treat these levels differently.

## Coverage types
Schedule assignments should label whether a person is covering a station as:
- stable coverage
- learning coverage
- emergency coverage

## Decision priorities
1. validity
2. service protection
3. bottleneck protection
4. cost control
5. training progression
6. fairness

## Failure mode policy
If constraints are infeasible:
- do not fake completeness
- state the exact contradiction
- provide smallest repair options
- optionally produce best-effort draft if useful, clearly labeled

## Versioning
Each file should be versionable and comparable over time.
Important changes include:
- new station capability
- staff absence pattern
- higher service intensity
- resolved vs unresolved contradictions


## Mapping rule
Before any solve attempt, the system must update the mapping layer from the latest `kitchen_state.md` and `week_constraints.md`, then regenerate the generated config used by the solver stack.

Any new constraint, objective, or static fact must flow in this order:
1. mapping layer
2. generated config
3. solver / validator / objective code

Do not inject restaurant facts directly into solver logic when they belong in the mapping layer.

## Reuse policy
If prior scheduling code already exists, first update the existing mapping file and regenerate config for the latest week, then modify only the minimum necessary solver logic.
Do not jump straight into solving on outdated values.
Keep the implementation lean: prefer one mapping file and one generated config file.
