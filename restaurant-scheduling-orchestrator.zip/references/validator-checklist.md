# Validator checklist

Use this checklist before and after schedule generation.

## Pre-schedule feasibility checks
- Static and weekly truth layers do not conflict without being flagged.
- Every critical station has enough qualified people for required service days.
- Peak vs slow staffing mode is explicitly chosen or inferable.
- Merged station plans use only people actually capable of handling those merged loads.
- Temporary unavailability does not remove all coverage from bottleneck stations.
- Expeditor / pass leadership coverage is defined.
- Developmental staff are not implicitly treated as fully independent unless stated.
- AM emergency support is not used as normal PM staffing unless explicitly allowed.

## Hard constraint checks after schedule generation
- Every required station is covered at required headcount, or the gap is flagged.
- No employee is assigned to a station outside their allowed capability level.
- No employee is assigned while unavailable.
- No fixed-off or no-overtime rule is violated.
- No employee is double-booked.
- No undefined station or invented role appears.
- If a merged station is used, that merge is allowed in the truth layers.
- If a person is marked emergency-only for a station, the schedule labels the assignment appropriately.

## Quality and operational risk checks
- Single-point-of-failure coverage is highlighted.
- Rare-skill staff are not overused without explanation.
- Training reps are safe, not reckless.
- The schedule respects this week's service intensity where feasible.
- Assumptions are listed explicitly.
- Workbook and report agree on the same assignments.

## Validation severity model
- ERROR = violates a hard constraint or makes the schedule operationally invalid
- WARNING = technically feasible but fragile or weak
- INFO = assumption, clarification, or non-blocking note

## Contradiction report format
For each contradiction include:
1. rule name
2. why it conflicts
3. exact people / stations / days involved
4. severity: infeasible / high-risk / minor
5. smallest repair options
